# 🔍 AI Defect Detection System

An end-to-end deep learning system for manufacturing quality control.

## 📁 Project Structure
```
ai_defect_detection/
├── data/
│   ├── train/
│   │   ├── defective/     ← Put defective images here
│   │   └── good/          ← Put good images here
│   └── val/
│       ├── defective/
│       └── good/
├── models/
│   ├── saved/             ← Trained .pt model saved here
│   └── exports/           ← ONNX model exported here
├── src/
│   ├── dataset.py         ← Data loading & augmentation
│   ├── model.py           ← EfficientNet model + Focal Loss
│   ├── train.py           ← Training loop + MLflow tracking
│   ├── predict.py         ← Inference class
│   └── utils.py           ← ONNX export
├── api/
│   └── app.py             ← FastAPI REST server
├── dashboard/
│   └── app.py             ← Streamlit dashboard
├── config.yaml            ← All settings here
└── requirements.txt
```

## 🚀 Quick Start

### 1. Install dependencies
```bash
python -m venv defect_env
source defect_env/bin/activate   # Windows: defect_env\Scripts\activate
pip install -r requirements.txt
```

### 2. Add your images
```
data/train/defective/  ← defective product images
data/train/good/       ← good product images
data/val/defective/
data/val/good/
```

### 3. Train the model
```bash
cd src
python train.py
```

### 4. Export to ONNX (optional, for edge deployment)
```bash
python utils.py
```

### 5. Start API server
```bash
cd ../api
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

### 6. Launch dashboard
```bash
cd ../dashboard
streamlit run app.py
```

### 7. View experiment tracking
```bash
cd ..
mlflow ui --port 5000
```

## 🌐 Services

| Service | URL |
|---|---|
| FastAPI Docs | http://localhost:8000/docs |
| Streamlit Dashboard | http://localhost:8501 |
| MLflow Tracking | http://localhost:5000 |

## ⚙️ Configuration

Edit `config.yaml` to change:
- Model architecture (`efficientnet_b3`, `resnet50`, `vit_base`)
- Batch size, learning rate, epochs
- Image size, augmentation settings
