import sys
import os
import io
import uvicorn
import numpy as np
from PIL import Image
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

sys.path.append(os.path.join(os.path.dirname(__file__), '../src'))
from predict import DefectDetector

app = FastAPI(
    title="AI Defect Detection API",
    description="Real-time defect detection for manufacturing quality control",
    version="1.0.0"
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

detector = DefectDetector(config_path="../config.yaml")


class PredictionResponse(BaseModel):
    prediction: str
    confidence: float
    probabilities: dict
    inference_time_ms: float
    status: str


@app.get("/health")
def health_check():
    return {"status": "healthy", "model": "loaded"}


@app.post("/predict", response_model=PredictionResponse)
async def predict(file: UploadFile = File(...)):
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")
    try:
        contents = await file.read()
        image = np.array(Image.open(io.BytesIO(contents)).convert("RGB"))
        result = detector.predict(image)
        result["status"] = "success"
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/predict-batch")
async def predict_batch(files: list[UploadFile] = File(...)):
    results = []
    for file in files:
        contents = await file.read()
        image = np.array(Image.open(io.BytesIO(contents)).convert("RGB"))
        result = detector.predict(image)
        result["filename"] = file.filename
        results.append(result)
    return {"results": results, "total": len(results)}


if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
