import sys
import os
import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image
import plotly.express as px
import plotly.graph_objects as go

sys.path.append(os.path.join(os.path.dirname(__file__), '../src'))
from predict import DefectDetector

st.set_page_config(page_title="AI Defect Detection", page_icon="🔍", layout="wide")
st.title("🔍 AI Defect Detection Dashboard")
st.markdown("Real-time quality inspection powered by deep learning")


@st.cache_resource
def load_model():
    return DefectDetector(config_path="../config.yaml")


detector = load_model()

st.sidebar.header("⚙️ Settings")
confidence_threshold = st.sidebar.slider("Confidence Threshold (%)", 50, 99, 80)
show_probabilities = st.sidebar.checkbox("Show Probabilities", True)

if "history" not in st.session_state:
    st.session_state.history = []

col1, col2 = st.columns([1, 1])

with col1:
    st.subheader("📤 Upload Image")
    uploaded_file = st.file_uploader("Choose an image", type=["jpg", "jpeg", "png", "bmp"])

    if uploaded_file:
        image = Image.open(uploaded_file).convert("RGB")
        st.image(image, caption="Uploaded Image", use_column_width=True)

        if st.button("🔍 Analyze", type="primary"):
            with st.spinner("Analyzing..."):
                result = detector.predict(np.array(image))

            st.session_state.history.append({
                "filename": uploaded_file.name,
                "prediction": result["prediction"],
                "confidence": result["confidence"],
                "time_ms": result["inference_time_ms"],
                "timestamp": pd.Timestamp.now().strftime("%H:%M:%S")
            })

            st.subheader("📊 Result")
            if result["prediction"] == "defective":
                st.error(f"⚠️ DEFECTIVE — {result['confidence']}% confidence")
            else:
                st.success(f"✅ GOOD — {result['confidence']}% confidence")

            st.metric("Inference Time", f"{result['inference_time_ms']} ms")

            if show_probabilities:
                probs = result["probabilities"]
                fig = go.Figure(go.Bar(
                    x=list(probs.keys()),
                    y=list(probs.values()),
                    marker_color=["#ef4444", "#22c55e"]
                ))
                fig.update_layout(title="Class Probabilities (%)", yaxis_title="Probability (%)", height=300)
                st.plotly_chart(fig, use_container_width=True)

with col2:
    st.subheader("📈 Inspection History")
    if st.session_state.history:
        df = pd.DataFrame(st.session_state.history)
        st.dataframe(df, use_container_width=True)

        defect_count = (df["prediction"] == "defective").sum()
        good_count = (df["prediction"] == "good").sum()

        m1, m2, m3 = st.columns(3)
        m1.metric("Total Inspected", len(df))
        m2.metric("Defective", defect_count)
        m3.metric("Good", good_count)

        fig2 = px.pie(values=[defect_count, good_count], names=["Defective", "Good"],
                      color_discrete_map={"Defective": "#ef4444", "Good": "#22c55e"},
                      title="Defect Rate")
        st.plotly_chart(fig2, use_container_width=True)

        if st.button("🗑️ Clear History"):
            st.session_state.history = []
            st.rerun()
    else:
        st.info("Upload and analyze images to see history here.")
