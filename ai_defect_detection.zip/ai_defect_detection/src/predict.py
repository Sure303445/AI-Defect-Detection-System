import os
import sys
import torch
import cv2
import numpy as np
import yaml
import time
import albumentations as A
from albumentations.pytorch import ToTensorV2

sys.path.append(os.path.dirname(__file__))
from model import build_model


class DefectDetector:
    def __init__(self, config_path="config.yaml", model_path=None):
        with open(config_path) as f:
            self.config = yaml.safe_load(f)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.class_names = ["defective", "good"]
        model_path = model_path or self.config['paths']['model_save']
        self.model = build_model(self.config['model']['name'],
                                 self.config['model']['num_classes'],
                                 pretrained=False).to(self.device)
        self.model.load_state_dict(torch.load(model_path, map_location=self.device))
        self.model.eval()
        image_size = self.config['data']['image_size']
        self.transform = A.Compose([
            A.Resize(image_size, image_size),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2(),
        ])
        print(f"✅ Model loaded | Device: {self.device}")

    def predict(self, image_input):
        if isinstance(image_input, str):
            image = cv2.imread(image_input)
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        else:
            image = image_input
        tensor = self.transform(image=image)['image'].unsqueeze(0).to(self.device)
        start = time.time()
        with torch.no_grad():
            probs = torch.softmax(self.model(tensor), dim=1)
        elapsed = (time.time() - start) * 1000
        pred_idx = probs.argmax(1).item()
        return {
            "prediction": self.class_names[pred_idx],
            "confidence": round(probs[0][pred_idx].item() * 100, 2),
            "probabilities": {cls: round(probs[0][i].item() * 100, 2)
                              for i, cls in enumerate(self.class_names)},
            "inference_time_ms": round(elapsed, 2)
        }

    def predict_batch(self, image_paths):
        return [self.predict(p) for p in image_paths]


if __name__ == "__main__":
    detector = DefectDetector()
    result = detector.predict("data/val/defective/sample.jpg")
    print(result)
