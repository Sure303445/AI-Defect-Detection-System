import os
import sys
import yaml
import torch
import mlflow
from tqdm import tqdm
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.append(os.path.dirname(__file__))
from dataset import get_dataloaders
from model import build_model, FocalLoss


def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss, correct, total = 0, 0, 0
    for images, labels in tqdm(loader, desc="Training"):
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        correct += (outputs.argmax(1) == labels).sum().item()
        total += labels.size(0)
    return total_loss / len(loader), correct / total


@torch.no_grad()
def validate(model, loader, criterion, device):
    model.eval()
    total_loss, correct, total = 0, 0, 0
    all_preds, all_labels = [], []
    for images, labels in tqdm(loader, desc="Validation"):
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        loss = criterion(outputs, labels)
        total_loss += loss.item()
        preds = outputs.argmax(1)
        correct += (preds == labels).sum().item()
        total += labels.size(0)
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())
    return total_loss / len(loader), correct / total, all_preds, all_labels


def plot_confusion_matrix(labels, preds, class_names, save_path="confusion_matrix.png"):
    cm = confusion_matrix(labels, preds)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=class_names, yticklabels=class_names)
    plt.title("Confusion Matrix")
    plt.ylabel("True Label")
    plt.xlabel("Predicted Label")
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()


def train(config_path="config.yaml"):
    with open(config_path) as f:
        config = yaml.safe_load(f)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    train_loader, val_loader, class_names = get_dataloaders(config)
    model = build_model(config['model']['name'], config['model']['num_classes'],
                        config['model']['pretrained'], config['model']['dropout']).to(device)
    criterion = FocalLoss()
    optimizer = torch.optim.AdamW(model.parameters(),
                                  lr=config['training']['learning_rate'],
                                  weight_decay=config['training']['weight_decay'])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=config['training']['epochs'])

    mlflow.set_tracking_uri(config['paths']['mlflow_uri'])
    mlflow.set_experiment("defect_detection")

    best_val_acc, patience_counter = 0, 0
    patience = config['training']['early_stopping_patience']

    with mlflow.start_run():
        mlflow.log_params({**config['training'], **config['model']})
        for epoch in range(1, config['training']['epochs'] + 1):
            train_loss, train_acc = train_one_epoch(model, train_loader, optimizer, criterion, device)
            val_loss, val_acc, val_preds, val_labels = validate(model, val_loader, criterion, device)
            scheduler.step()

            print(f"Epoch [{epoch}/{config['training']['epochs']}] "
                  f"Train: {train_acc:.4f} | Val: {val_acc:.4f}")
            mlflow.log_metrics({"train_loss": train_loss, "train_acc": train_acc,
                                 "val_loss": val_loss, "val_acc": val_acc}, step=epoch)

            if val_acc > best_val_acc:
                best_val_acc = val_acc
                patience_counter = 0
                os.makedirs(os.path.dirname(config['paths']['model_save']), exist_ok=True)
                torch.save(model.state_dict(), config['paths']['model_save'])
                print(f"  ✅ Best model saved! Val Acc: {best_val_acc:.4f}")
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    print(f"Early stopping at epoch {epoch}")
                    break

        print("\n📊 Classification Report:")
        print(classification_report(val_labels, val_preds, target_names=class_names))
        plot_confusion_matrix(val_labels, val_preds, class_names)
        mlflow.log_artifact("confusion_matrix.png")


if __name__ == "__main__":
    train()
