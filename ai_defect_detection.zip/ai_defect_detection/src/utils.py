import sys
import os
import torch
import onnx
import onnxruntime as ort
import numpy as np
import yaml

sys.path.append(os.path.dirname(__file__))
from model import build_model


def export_to_onnx(config_path="config.yaml"):
    with open(config_path) as f:
        config = yaml.safe_load(f)

    model = build_model(config['model']['name'], config['model']['num_classes'], pretrained=False)
    model.load_state_dict(torch.load(config['paths']['model_save'], map_location='cpu'))
    model.eval()

    image_size = config['data']['image_size']
    dummy_input = torch.randn(1, 3, image_size, image_size)

    export_path = config['paths']['onnx_export']
    os.makedirs(os.path.dirname(export_path), exist_ok=True)

    torch.onnx.export(model, dummy_input, export_path, opset_version=11,
                      input_names=['input'], output_names=['output'],
                      dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}})

    onnx.checker.check_model(onnx.load(export_path))
    print(f"✅ ONNX model exported: {export_path}")

    ort_session = ort.InferenceSession(export_path)
    out = ort_session.run(None, {'input': dummy_input.numpy()})
    print(f"ONNX test output shape: {out[0].shape}")


if __name__ == "__main__":
    export_to_onnx()
